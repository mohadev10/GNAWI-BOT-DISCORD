require('dotenv').config();
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const logger = require('./utils/logger');
const { ensureTempDir } = require('./utils/cleanup');

// Validate required env vars
if (!config.token) {
  logger.error('DISCORD_TOKEN is not set. Please add it to your environment secrets.');
  process.exit(1);
}
if (!config.clientId) {
  logger.error('DISCORD_CLIENT_ID is not set. Please add it to your environment secrets.');
  process.exit(1);
}

// Ensure temp directory exists
ensureTempDir();

// Create Discord client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
  ],
});

// Load commands
client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));

for (const file of commandFiles) {
  try {
    const command = require(path.join(commandsPath, file));
    if (command.data && command.execute) {
      client.commands.set(command.data.name, command);
      logger.info(`Loaded command: /${command.data.name}`);
    } else {
      logger.warn(`Skipping ${file}: missing data or execute`);
    }
  } catch (err) {
    logger.error(`Failed to load command ${file}: ${err.message}`);
  }
}

// Load events
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));

for (const file of eventFiles) {
  try {
    const event = require(path.join(eventsPath, file));
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args));
    } else {
      client.on(event.name, (...args) => event.execute(...args));
    }
    logger.info(`Loaded event: ${event.name}`);
  } catch (err) {
    logger.error(`Failed to load event ${file}: ${err.message}`);
  }
}

// Global error handlers to prevent crashes
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err);
  // Don't exit — keep the bot running
});

process.on('SIGINT', () => {
  logger.info('Received SIGINT. Gracefully shutting down...');
  client.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  logger.info('Received SIGTERM. Gracefully shutting down...');
  client.destroy();
  process.exit(0);
});

// Login
logger.info('Starting Discord bot...');
client.login(config.token).catch(err => {
  logger.error('Failed to login:', err.message);
  process.exit(1);
});
