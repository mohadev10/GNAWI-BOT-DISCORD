
const config = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,

  // Cooldown per user in seconds
  cooldown: 15,

  // Max queue size per guild
  maxQueueSize: 10,

  // Max file size Discord allows (in bytes) - 25MB for regular, 100MB for Nitro
  maxFileSize: 25 * 1024 * 1024,

  // Temp directory for downloaded files
  tempDir: './temp',

  // Supported quality options
  qualities: ['144p', '360p', '720p', '1080p', 'mp3'],

  // yt-dlp path (system install)
  ytDlpPath: 'yt-dlp',

  // ffmpeg path (system install)
  ffmpegPath: 'ffmpeg',

  // Log level
  logLevel: 'info',

  // Auto-update yt-dlp on startup
  autoUpdate: true,

  // Colors for embeds
  colors: {
    primary: 0x5865F2,
    success: 0x57F287,
    warning: 0xFEE75C,
    error: 0xED4245,
    info: 0x5865F2,
  },
};

module.exports = config;
