const { Events } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config');
const logger = require('../utils/logger');
const { updateYtDlp } = require('../utils/ytdlp');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    logger.info(`✅ Logged in as ${client.user.tag}`);
    logger.info(`📡 Serving ${client.guilds.cache.size} guild(s)`);

    // Set bot presence
    client.user.setPresence({
      activities: [{ name: '/download | /help', type: 3 }],
      status: 'online',
    });

    // Register slash commands globally
    try {
      const commands = [];
      const commandsPath = path.join(__dirname, '..', 'commands');
      const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));
      for (const file of commandFiles) {
        const command = require(path.join(commandsPath, file));
        if (command.data) commands.push(command.data.toJSON());
      }

      const rest = new REST({ version: '10' }).setToken(config.token);
      logger.info(`Registering ${commands.length} slash commands...`);
      await rest.put(Routes.applicationCommands(config.clientId), { body: commands });
      logger.info(`✅ Successfully registered ${commands.length} slash commands globally`);
    } catch (err) {
      logger.error('Failed to register slash commands:', err);
    }

    // Auto-update yt-dlp
    if (config.autoUpdate) {
      await updateYtDlp();
    }
  },
};
