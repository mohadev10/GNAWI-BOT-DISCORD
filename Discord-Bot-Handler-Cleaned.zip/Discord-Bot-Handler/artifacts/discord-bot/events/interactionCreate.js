const { Events, EmbedBuilder } = require('discord.js');
const logger = require('../utils/logger');
const config = require('../config');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    if (!interaction.isChatInputCommand()) return;

    const command = interaction.client.commands.get(interaction.commandName);
    if (!command) {
      logger.warn(`Unknown command: ${interaction.commandName}`);
      return;
    }

    try {
      logger.info(`[CMD] ${interaction.user.tag} used /${interaction.commandName} in ${interaction.guild?.name || 'DM'}`);
      await command.execute(interaction);
    } catch (err) {
      logger.error(`Error executing /${interaction.commandName}: ${err.message}`, err);

      const errorEmbed = new EmbedBuilder()
        .setColor(config.colors.error)
        .setTitle('❌ An Error Occurred')
        .setDescription('Something went wrong while executing this command. Please try again.')
        .setTimestamp();

      try {
        if (interaction.replied || interaction.deferred) {
          await interaction.editReply({ embeds: [errorEmbed], files: [] }).catch(() => {});
        } else {
          await interaction.reply({ embeds: [errorEmbed], ephemeral: true }).catch(() => {});
        }
      } catch (replyErr) {
        logger.error('Failed to send error reply:', replyErr.message);
      }
    }
  },
};
