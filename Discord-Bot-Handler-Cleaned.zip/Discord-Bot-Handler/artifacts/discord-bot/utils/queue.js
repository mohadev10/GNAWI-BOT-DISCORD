const PQueue = require('p-queue').default;
const logger = require('./logger');
const config = require('../config');

// Per-guild queues
const guildQueues = new Map();
// Per-user cooldowns: userId -> timestamp
const cooldowns = new Map();

function getGuildQueue(guildId) {
  if (!guildQueues.has(guildId)) {
    const queue = new PQueue({ concurrency: 2 });
    queue.on('error', (err) => logger.error(`Queue error in guild ${guildId}:`, err));
    guildQueues.set(guildId, queue);
  }
  return guildQueues.get(guildId);
}

function checkCooldown(userId) {
  const now = Date.now();
  if (cooldowns.has(userId)) {
    const last = cooldowns.get(userId);
    const diff = Math.ceil((config.cooldown * 1000 - (now - last)) / 1000);
    if (diff > 0) return diff;
  }
  cooldowns.set(userId, now);
  return 0;
}

function getQueueSize(guildId) {
  const queue = guildQueues.get(guildId);
  if (!queue) return 0;
  return queue.size + queue.pending;
}

async function addToQueue(guildId, task) {
  const queue = getGuildQueue(guildId);
  const queueSize = queue.size + queue.pending;
  if (queueSize >= config.maxQueueSize) {
    throw new Error(`Queue is full (${config.maxQueueSize} tasks). Please wait.`);
  }
  return queue.add(task);
}

// Cleanup old cooldowns periodically
setInterval(() => {
  const now = Date.now();
  for (const [userId, timestamp] of cooldowns.entries()) {
    if (now - timestamp > config.cooldown * 1000 * 2) {
      cooldowns.delete(userId);
    }
  }
}, 60000);

module.exports = { getGuildQueue, checkCooldown, getQueueSize, addToQueue };
