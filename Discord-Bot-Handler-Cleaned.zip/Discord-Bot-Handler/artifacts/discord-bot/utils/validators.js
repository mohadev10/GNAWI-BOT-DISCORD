const URL_REGEX = /^(https?:\/\/)?(www\.)?([-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6})\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)$/;

const SUPPORTED_DOMAINS = [
  'youtube.com', 'youtu.be',
  'tiktok.com',
  'instagram.com',
  'facebook.com', 'fb.watch',
  'twitter.com', 'x.com', 't.co',
  'twitch.tv',
  'vimeo.com',
  'reddit.com', 'v.redd.it',
  'soundcloud.com',
  'pinterest.com', 'pin.it',
  'snapchat.com',
  'dailymotion.com',
  'bilibili.com',
  'nicovideo.jp',
  'streamable.com',
  'rumble.com',
  'odysee.com',
];

function isValidUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function detectPlatform(url) {
  try {
    const hostname = new URL(url).hostname.replace('www.', '');
    if (hostname.includes('youtube.com') || hostname === 'youtu.be') return 'YouTube';
    if (hostname.includes('tiktok.com')) return 'TikTok';
    if (hostname.includes('instagram.com')) return 'Instagram';
    if (hostname.includes('facebook.com') || hostname === 'fb.watch') return 'Facebook';
    if (hostname.includes('twitter.com') || hostname.includes('x.com')) return 'Twitter/X';
    if (hostname.includes('twitch.tv')) return 'Twitch';
    if (hostname.includes('vimeo.com')) return 'Vimeo';
    if (hostname.includes('reddit.com') || hostname === 'v.redd.it') return 'Reddit';
    if (hostname.includes('soundcloud.com')) return 'SoundCloud';
    if (hostname.includes('pinterest.com') || hostname === 'pin.it') return 'Pinterest';
    if (hostname.includes('snapchat.com')) return 'Snapchat';
    if (hostname.includes('dailymotion.com')) return 'Dailymotion';
    return 'Unknown';
  } catch {
    return 'Unknown';
  }
}

function formatDuration(seconds) {
  if (!seconds || isNaN(seconds)) return 'Unknown';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function formatFileSize(bytes) {
  if (!bytes || isNaN(bytes)) return 'Unknown';
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let i = 0;
  while (size >= 1024 && i < units.length - 1) { size /= 1024; i++; }
  return `${size.toFixed(2)} ${units[i]}`;
}

function createProgressBar(percent, length = 20) {
  const filled = Math.round((percent / 100) * length);
  const empty = length - filled;
  return `[${'█'.repeat(filled)}${'░'.repeat(empty)}] ${percent.toFixed(1)}%`;
}

module.exports = { isValidUrl, detectPlatform, formatDuration, formatFileSize, createProgressBar, SUPPORTED_DOMAINS };
