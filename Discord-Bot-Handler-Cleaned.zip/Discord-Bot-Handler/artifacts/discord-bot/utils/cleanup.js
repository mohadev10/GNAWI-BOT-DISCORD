const fs = require('fs');
const path = require('path');
const logger = require('./logger');

const tempDir = path.join(__dirname, '..', 'temp');

function ensureTempDir() {
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
  }
}

function deleteFile(filePath) {
  if (!filePath) return;
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      logger.debug(`Deleted temp file: ${filePath}`);
    }
  } catch (err) {
    logger.warn(`Could not delete temp file ${filePath}: ${err.message}`);
  }
}

function deleteFilesWithPrefix(dir, prefix) {
  try {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      if (file.startsWith(prefix)) {
        deleteFile(path.join(dir, file));
      }
    }
  } catch (err) {
    logger.warn(`Cleanup error in ${dir}: ${err.message}`);
  }
}

// Clean temp files older than 1 hour on startup and periodically
function cleanOldTempFiles() {
  ensureTempDir();
  try {
    const files = fs.readdirSync(tempDir);
    const now = Date.now();
    let count = 0;
    for (const file of files) {
      const filePath = path.join(tempDir, file);
      try {
        const stat = fs.statSync(filePath);
        if (now - stat.mtimeMs > 60 * 60 * 1000) {
          fs.unlinkSync(filePath);
          count++;
        }
      } catch {}
    }
    if (count > 0) logger.info(`Cleaned ${count} old temp files`);
  } catch (err) {
    logger.warn(`Failed to clean temp dir: ${err.message}`);
  }
}

// Run on startup and every 30 minutes
cleanOldTempFiles();
setInterval(cleanOldTempFiles, 30 * 60 * 1000);

module.exports = { ensureTempDir, deleteFile, deleteFilesWithPrefix, cleanOldTempFiles, tempDir };
