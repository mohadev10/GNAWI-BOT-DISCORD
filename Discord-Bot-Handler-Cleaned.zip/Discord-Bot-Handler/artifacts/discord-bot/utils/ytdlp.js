const { exec, spawn } = require('child_process');
const { promisify } = require('util');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const logger = require('./logger');

const execAsync = promisify(exec);

const QUALITY_MAP = {
  '144p':  'bestvideo[height<=144]+bestaudio/best[height<=144]/worst',
  '360p':  'bestvideo[height<=360]+bestaudio/best[height<=360]/bestvideo[height<=480]+bestaudio',
  '720p':  'bestvideo[height<=720]+bestaudio/best[height<=720]',
  '1080p': 'bestvideo[height<=1080]+bestaudio/best[height<=1080]',
  'mp3':   'bestaudio/best',
};

async function updateYtDlp() {
  try {
    logger.info('Checking for yt-dlp updates...');
    const { stdout } = await execAsync(`${config.ytDlpPath} --version`);
    logger.info(`yt-dlp version: ${stdout.trim()}`);
  } catch (err) {
    logger.error('Failed to check yt-dlp version:', err.message);
  }
}

async function getMediaInfo(url) {
  return new Promise((resolve, reject) => {
    const args = [
      '--dump-json',
      '--no-playlist',
      '--socket-timeout', '30',
      '--no-warnings',
      url,
    ];

    const proc = spawn(config.ytDlpPath, args, { timeout: 60000 });
    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', d => { stdout += d.toString(); });
    proc.stderr.on('data', d => { stderr += d.toString(); });

    proc.on('close', (code) => {
      if (code !== 0) {
        const errMsg = parseYtDlpError(stderr);
        return reject(new Error(errMsg));
      }
      try {
        const info = JSON.parse(stdout);
        resolve({
          title: info.title || 'Unknown Title',
          duration: info.duration || 0,
          uploader: info.uploader || info.channel || 'Unknown',
          thumbnail: info.thumbnail || null,
          webpage_url: info.webpage_url || url,
          ext: info.ext || 'mp4',
          filesize: info.filesize || info.filesize_approx || null,
          formats: info.formats || [],
          is_live: info.is_live || false,
          platform: info.extractor_key || 'Unknown',
          view_count: info.view_count || null,
          like_count: info.like_count || null,
          description: info.description ? info.description.slice(0, 200) : null,
        });
      } catch {
        reject(new Error('Failed to parse media information'));
      }
    });

    proc.on('error', (err) => reject(new Error(`yt-dlp not found: ${err.message}`)));
    setTimeout(() => { proc.kill(); reject(new Error('Request timed out after 60 seconds')); }, 60000);
  });
}

function downloadMedia(url, quality, outputPath, onProgress) {
  return new Promise((resolve, reject) => {
    const isAudio = quality === 'mp3';
    const format = QUALITY_MAP[quality] || QUALITY_MAP['720p'];

    const args = [
      '--no-playlist',
      '--socket-timeout', '30',
      '--no-warnings',
      '--newline',
      '-f', format,
      '--merge-output-format', isAudio ? 'mp3' : 'mp4',
    ];

    if (isAudio) {
      args.push('-x', '--audio-format', 'mp3', '--audio-quality', '0');
    } else {
      args.push('--recode-video', 'mp4');
    }

    args.push('--ffmpeg-location', config.ffmpegPath);
    args.push('-o', outputPath);
    args.push(url);

    const proc = spawn(config.ytDlpPath, args);
    let stderr = '';

    proc.stdout.on('data', (data) => {
      const line = data.toString();
      const match = line.match(/(\d+\.?\d*)%/);
      if (match && onProgress) {
        onProgress(parseFloat(match[1]));
      }
    });

    proc.stderr.on('data', d => { stderr += d.toString(); });

    proc.on('close', (code) => {
      if (code !== 0) {
        return reject(new Error(parseYtDlpError(stderr)));
      }
      // yt-dlp may add extension
      const finalPath = findOutputFile(outputPath, isAudio ? 'mp3' : 'mp4');
      resolve(finalPath);
    });

    proc.on('error', (err) => reject(new Error(`yt-dlp error: ${err.message}`)));
  });
}

function findOutputFile(basePath, ext) {
  const withExt = basePath.replace(/\.\w+$/, '') + '.' + ext;
  if (fs.existsSync(withExt)) return withExt;
  if (fs.existsSync(basePath)) return basePath;
  // search the directory
  const dir = path.dirname(basePath);
  const base = path.basename(basePath, path.extname(basePath));
  try {
    const files = fs.readdirSync(dir).filter(f => f.startsWith(base));
    if (files.length > 0) return path.join(dir, files[0]);
  } catch {}
  return basePath;
}

function parseYtDlpError(stderr) {
  if (!stderr) return 'Download failed';
  if (stderr.includes('age')) return 'This video is age-restricted and cannot be downloaded';
  if (stderr.includes('private')) return 'This video is private';
  if (stderr.includes('not available')) return 'This video is not available in your region';
  if (stderr.includes('removed') || stderr.includes('deleted')) return 'This video has been removed';
  if (stderr.includes('copyright')) return 'This video is not available due to copyright restrictions';
  if (stderr.includes('rate')) return 'Rate limited. Please wait a moment and try again';
  if (stderr.includes('Unable to extract') || stderr.includes('Unsupported URL')) return 'This URL is not supported';
  if (stderr.includes('No video formats found')) return 'No downloadable formats found for this URL';
  const match = stderr.match(/ERROR: (.+)/);
  return match ? match[1].trim() : 'Download failed. Please check the URL and try again';
}

async function downloadThumbnail(url, outputPath) {
  return new Promise((resolve, reject) => {
    const args = [
      '--write-thumbnail',
      '--skip-download',
      '--no-playlist',
      '--convert-thumbnails', 'png',
      '-o', outputPath,
      url,
    ];
    const proc = spawn(config.ytDlpPath, args);
    let stderr = '';
    proc.stderr.on('data', d => { stderr += d.toString(); });
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(parseYtDlpError(stderr)));
      const thumbPath = findOutputFile(outputPath, 'png') || findOutputFile(outputPath, 'jpg') || findOutputFile(outputPath, 'webp');
      resolve(thumbPath);
    });
    proc.on('error', (err) => reject(new Error(`yt-dlp error: ${err.message}`)));
  });
}

module.exports = { updateYtDlp, getMediaInfo, downloadMedia, downloadThumbnail, parseYtDlpError };
