const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');
const { getMediaInfo } = require('../utils/ytdlp');
const { isValidUrl, detectPlatform, formatDuration, formatFileSize } = require('../utils/validators');
const { checkCooldown } = require('../utils/queue');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('info')
    .setDescription('Get detailed information about a media URL without downloading')
    .addStringOption(opt =>
      opt.setName('url')
        .setDescription('The URL to get info about')
        .setRequired(true)),

  async execute(interaction) {
    const url = interaction.options.getString('url');
    const userId = interaction.user.id;

    if (!isValidUrl(url)) {
      return interaction.reply({
        embeds: [errorEmbed('Invalid URL', 'Please provide a valid URL starting with http:// or https://')],
        ephemeral: true,
      });
    }

    const remaining = checkCooldown(userId);
    if (remaining > 0) {
      return interaction.reply({
        embeds: [errorEmbed('Cooldown Active', `Please wait **${remaining}s** before your next request.`)],
        ephemeral: true,
      });
    }

    await interaction.deferReply();
    const platform = detectPlatform(url);

    try {
      const fetchEmbed = new EmbedBuilder()
        .setColor(config.colors.info)
        .setTitle('🔍 Fetching Media Info...')
        .setDescription(`Looking up info for **${platform}** URL...`);
      await interaction.editReply({ embeds: [fetchEmbed] });

      const info = await getMediaInfo(url);

      const embed = new EmbedBuilder()
        .setColor(config.colors.primary)
        .setTitle(`📋 Media Information`)
        .setDescription(`**[${info.title}](${info.webpage_url})**`)
        .addFields(
          { name: '⏱ Duration', value: formatDuration(info.duration), inline: true },
          { name: '🌐 Platform', value: platform, inline: true },
          { name: '👤 Uploader', value: info.uploader || 'Unknown', inline: true },
          { name: '💾 Approx. Size', value: info.filesize ? formatFileSize(info.filesize) : 'Unknown', inline: true },
          { name: '🎞 Format', value: info.ext ? info.ext.toUpperCase() : 'Unknown', inline: true },
          { name: '📡 Source', value: info.platform || platform, inline: true },
        )
        .setFooter({ text: `Requested by ${interaction.user.tag}` })
        .setTimestamp();

      if (info.view_count) embed.addFields({ name: '👁 Views', value: info.view_count.toLocaleString(), inline: true });
      if (info.like_count) embed.addFields({ name: '👍 Likes', value: info.like_count.toLocaleString(), inline: true });
      if (info.description) embed.addFields({ name: '📝 Description', value: info.description + (info.description.length >= 200 ? '...' : ''), inline: false });
      if (info.is_live) embed.addFields({ name: '🔴 Status', value: 'LIVE', inline: true });

      if (info.thumbnail) embed.setImage(info.thumbnail);

      await interaction.editReply({ embeds: [embed] });
      logger.info(`[info] ${interaction.user.tag} fetched info for ${url}`);
    } catch (err) {
      logger.error(`[info] Error for ${url}: ${err.message}`);
      await interaction.editReply({ embeds: [errorEmbed('Failed to Fetch Info', err.message)] });
    }
  },
};

function errorEmbed(title, description) {
  return new EmbedBuilder().setColor(0xED4245).setTitle(`❌ ${title}`).setDescription(description).setTimestamp();
}
