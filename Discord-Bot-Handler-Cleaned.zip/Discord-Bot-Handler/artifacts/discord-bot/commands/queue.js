const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');
const { getQueueSize } = require('../utils/queue');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Show the current download queue for this server'),

  async execute(interaction) {
    const guildId = interaction.guildId || 'dm';
    const size = getQueueSize(guildId);

    const embed = new EmbedBuilder()
      .setColor(config.colors.info)
      .setTitle('📋 Download Queue')
      .addFields(
        { name: '🔄 Tasks in Queue', value: `${size} / ${config.maxQueueSize}`, inline: true },
        { name: '⏳ Status', value: size === 0 ? '✅ Queue is empty' : `⏳ ${size} task(s) processing`, inline: true },
        { name: '⏱ Cooldown', value: `${config.cooldown}s per user`, inline: true },
      )
      .setFooter({ text: `Server: ${interaction.guild?.name || 'DM'}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
