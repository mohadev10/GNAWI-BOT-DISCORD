const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all available commands and supported platforms'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle('📥 Discord Downloader Bot — Help')
      .setDescription('Download videos and audio from 15+ platforms directly in Discord!')
      .addFields(
        {
          name: '📜 Commands',
          value: [
            '`/download <url> [quality]` — Download video or audio',
            '`/audio <url>` — Extract MP3 audio only',
            '`/info <url>` — Get media info without downloading',
            '`/thumbnail <url>` — Extract the video thumbnail',
            '`/queue` — View the current download queue',
            '`/help` — Show this help message',
          ].join('\n'),
        },
        {
          name: '🎬 Supported Platforms',
          value: [
            '🔴 YouTube • TikTok • Instagram',
            '📘 Facebook • Twitter/X • Twitch',
            '🎞 Vimeo • Reddit • SoundCloud',
            '📌 Pinterest • Snapchat • Dailymotion',
            '🌐 + Any site supported by yt-dlp',
          ].join('\n'),
        },
        {
          name: '📦 Quality Options',
          value: '`144p` `360p` `720p` `1080p` `mp3`',
          inline: true,
        },
        {
          name: '⏱ Cooldown',
          value: `${config.cooldown} seconds per user`,
          inline: true,
        },
        {
          name: '💾 File Size Limit',
          value: '25 MB (Discord limit)',
          inline: true,
        },
        {
          name: '💡 Tips',
          value: [
            '• Use `/audio` for music — faster and smaller files',
            '• Use `/info` to check a video before downloading',
            '• Large files need lower quality (144p or 360p)',
            '• Long videos are auto-suggested as MP3',
          ].join('\n'),
        },
      )
      .setFooter({ text: 'Powered by yt-dlp + ffmpeg' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
