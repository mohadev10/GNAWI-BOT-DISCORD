const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const { getMediaInfo, downloadMedia } = require('../utils/ytdlp');
const { isValidUrl, detectPlatform, formatDuration, formatFileSize, createProgressBar } = require('../utils/validators');
const { checkCooldown, addToQueue } = require('../utils/queue');
const { deleteFile, tempDir } = require('../utils/cleanup');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('audio')
    .setDescription('Extract audio as MP3 from any supported platform')
    .addStringOption(opt =>
      opt.setName('url')
        .setDescription('The URL of the video/audio to extract')
        .setRequired(true)),

  async execute(interaction) {
    const url = interaction.options.getString('url');
    const userId = interaction.user.id;
    const guildId = interaction.guildId || 'dm';

    if (!isValidUrl(url)) {
      return interaction.reply({
        embeds: [errorEmbed('Invalid URL', 'Please provide a valid URL.')],
        ephemeral: true,
      });
    }

    const remaining = checkCooldown(userId);
    if (remaining > 0) {
      return interaction.reply({
        embeds: [errorEmbed('Cooldown Active', `Please wait **${remaining}s** before your next request.`)],
        ephemeral: true,
      });
    }

    await interaction.deferReply();
    const platform = detectPlatform(url);

    let info;
    try {
      await interaction.editReply({
        embeds: [new EmbedBuilder().setColor(config.colors.info).setTitle('🎵 Extracting Audio...').setDescription(`Fetching info from **${platform}**...`)],
      });
      info = await getMediaInfo(url);
    } catch (err) {
      logger.error(`[audio] getMediaInfo failed: ${err.message}`);
      return interaction.editReply({ embeds: [errorEmbed('Failed to Fetch Info', err.message)] });
    }

    const progressEmbed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle('🎵 Extracting MP3...')
      .setDescription(`**${info.title}**`)
      .addFields(
        { name: '⏱ Duration', value: formatDuration(info.duration), inline: true },
        { name: '👤 Uploader', value: info.uploader || 'Unknown', inline: true },
        { name: '🔄 Progress', value: createProgressBar(0), inline: false },
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}` });

    if (info.thumbnail) progressEmbed.setThumbnail(info.thumbnail);
    await interaction.editReply({ embeds: [progressEmbed] });

    const tempFile = path.join(tempDir, `${Date.now()}_${userId}.%(ext)s`);
    let downloadedFile = null;

    try {
      await addToQueue(guildId, async () => {
        let lastPercent = 0;
        const onProgress = async (percent) => {
          if (percent - lastPercent < 15) return;
          lastPercent = percent;
          const updated = EmbedBuilder.from(progressEmbed).spliceFields(2, 1, { name: '🔄 Progress', value: createProgressBar(percent), inline: false });
          try { await interaction.editReply({ embeds: [updated] }); } catch {}
        };
        downloadedFile = await downloadMedia(url, 'mp3', tempFile, onProgress);
      });
    } catch (err) {
      logger.error(`[audio] download failed: ${err.message}`);
      deleteFile(downloadedFile);
      return interaction.editReply({ embeds: [errorEmbed('Audio Extraction Failed', err.message)] });
    }

    if (!downloadedFile || !fs.existsSync(downloadedFile)) {
      return interaction.editReply({ embeds: [errorEmbed('Audio Extraction Failed', 'File not found after extraction.')] });
    }

    const stats = fs.statSync(downloadedFile);
    const fileSize = stats.size;

    if (fileSize > config.maxFileSize) {
      deleteFile(downloadedFile);
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(config.colors.warning)
            .setTitle('⚠️ File Too Large')
            .setDescription(`The audio file is **${formatFileSize(fileSize)}** which exceeds Discord's 25MB limit.\n\nThis usually happens with very long videos. Please try a shorter one.`),
        ],
      });
    }

    const safeName = info.title.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 50) + '.mp3';

    const successEmbed = new EmbedBuilder()
      .setColor(config.colors.success)
      .setTitle('✅ Audio Extracted!')
      .setDescription(`**${info.title}**`)
      .addFields(
        { name: '🎵 Format', value: 'MP3', inline: true },
        { name: '💾 File Size', value: formatFileSize(fileSize), inline: true },
        { name: '⏱ Duration', value: formatDuration(info.duration), inline: true },
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}` })
      .setTimestamp();

    if (info.thumbnail) successEmbed.setThumbnail(info.thumbnail);

    try {
      await interaction.editReply({
        embeds: [successEmbed],
        files: [{ attachment: downloadedFile, name: safeName }],
      });
      logger.info(`[audio] Sent MP3 to ${interaction.user.tag} (${formatFileSize(fileSize)})`);
    } catch (err) {
      logger.error(`[audio] Failed to send: ${err.message}`);
      await interaction.editReply({ embeds: [errorEmbed('Send Failed', 'Could not send the audio file.')] });
    } finally {
      setTimeout(() => deleteFile(downloadedFile), 5000);
    }
  },
};

function errorEmbed(title, description) {
  return new EmbedBuilder().setColor(0xED4245).setTitle(`❌ ${title}`).setDescription(description).setTimestamp();
}
