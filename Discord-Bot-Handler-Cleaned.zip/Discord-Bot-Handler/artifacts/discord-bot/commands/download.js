const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const { getMediaInfo, downloadMedia } = require('../utils/ytdlp');
const { isValidUrl, detectPlatform, formatDuration, formatFileSize, createProgressBar } = require('../utils/validators');
const { checkCooldown, addToQueue } = require('../utils/queue');
const { deleteFile, tempDir } = require('../utils/cleanup');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('download')
    .setDescription('Download video or audio from any supported platform')
    .addStringOption(opt =>
      opt.setName('url')
        .setDescription('The URL of the video to download')
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('quality')
        .setDescription('Select download quality (default: 720p)')
        .setRequired(false)
        .addChoices(
          { name: '144p - Very Low', value: '144p' },
          { name: '360p - Low', value: '360p' },
          { name: '720p - HD (default)', value: '720p' },
          { name: '1080p - Full HD', value: '1080p' },
          { name: 'MP3 - Audio Only', value: 'mp3' },
        )),

  async execute(interaction) {
    const url = interaction.options.getString('url');
    const quality = interaction.options.getString('quality') || '720p';
    const userId = interaction.user.id;
    const guildId = interaction.guildId || 'dm';

    // Validate URL
    if (!isValidUrl(url)) {
      return interaction.reply({
        embeds: [errorEmbed('Invalid URL', 'Please provide a valid URL starting with http:// or https://')],
        ephemeral: true,
      });
    }

    // Check cooldown
    const remaining = checkCooldown(userId);
    if (remaining > 0) {
      return interaction.reply({
        embeds: [errorEmbed('Cooldown Active', `Please wait **${remaining}s** before your next download.`)],
        ephemeral: true,
      });
    }

    await interaction.deferReply();
    const platform = detectPlatform(url);

    // Fetch media info
    let info;
    try {
      const fetchingEmbed = new EmbedBuilder()
        .setColor(config.colors.info)
        .setTitle('🔍 Fetching Media Info...')
        .setDescription(`Platform: **${platform}**\nURL: \`${url.slice(0, 80)}${url.length > 80 ? '...' : ''}\``)
        .setFooter({ text: 'Please wait...' });
      await interaction.editReply({ embeds: [fetchingEmbed] });

      info = await getMediaInfo(url);
    } catch (err) {
      logger.error(`[download] getMediaInfo failed for ${url}: ${err.message}`);
      return interaction.editReply({ embeds: [errorEmbed('Failed to Fetch Info', err.message)] });
    }

    // Suggest MP3 for long videos
    let suggestion = '';
    if (info.duration > 600 && quality !== 'mp3') {
      suggestion = '\n> 💡 **Tip:** This video is over 10 minutes. Consider using `/audio` for MP3 to save time.';
    }

    // Show info + confirm embed
    const infoEmbed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle(`📥 Ready to Download`)
      .setDescription(`**${info.title}**${suggestion}`)
      .addFields(
        { name: '⏱ Duration', value: formatDuration(info.duration), inline: true },
        { name: '👤 Uploader', value: info.uploader || 'Unknown', inline: true },
        { name: '📦 Quality', value: quality.toUpperCase(), inline: true },
        { name: '💾 Est. Size', value: info.filesize ? formatFileSize(info.filesize) : 'Unknown', inline: true },
        { name: '🌐 Platform', value: platform, inline: true },
        { name: '🔄 Status', value: 'Starting download...', inline: true },
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}` })
      .setTimestamp();

    if (info.thumbnail) infoEmbed.setThumbnail(info.thumbnail);

    await interaction.editReply({ embeds: [infoEmbed] });

    // Queue the download
    const tempFile = path.join(tempDir, `${Date.now()}_${userId}.%(ext)s`);
    let downloadedFile = null;

    try {
      await addToQueue(guildId, async () => {
        // Update progress
        let lastPercent = 0;
        const onProgress = async (percent) => {
          if (percent - lastPercent < 10) return;
          lastPercent = percent;
          const progressEmbed = EmbedBuilder.from(infoEmbed)
            .spliceFields(5, 1, { name: '🔄 Progress', value: createProgressBar(percent), inline: false });
          try { await interaction.editReply({ embeds: [progressEmbed] }); } catch {}
        };

        downloadedFile = await downloadMedia(url, quality, tempFile, onProgress);
      });
    } catch (err) {
      logger.error(`[download] queue/download failed: ${err.message}`);
      deleteFile(downloadedFile);
      return interaction.editReply({ embeds: [errorEmbed('Download Failed', err.message)] });
    }

    if (!downloadedFile || !fs.existsSync(downloadedFile)) {
      return interaction.editReply({ embeds: [errorEmbed('Download Failed', 'File not found after download. Please try again.')] });
    }

    const stats = fs.statSync(downloadedFile);
    const fileSize = stats.size;

    // Check if file fits Discord's limit
    if (fileSize > config.maxFileSize) {
      deleteFile(downloadedFile);
      const sizeStr = formatFileSize(fileSize);
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(config.colors.warning)
            .setTitle('⚠️ File Too Large for Discord')
            .setDescription(`The file is **${sizeStr}** which exceeds Discord's 25MB limit.`)
            .addFields(
              { name: '💡 Suggestions', value: '• Try a lower quality (360p or 144p)\n• Use `/audio` for MP3 only\n• Use a Nitro account (100MB limit)' }
            )
            .setFooter({ text: `Requested by ${interaction.user.tag}` }),
        ],
      });
    }

    // Send file
    const ext = path.extname(downloadedFile).slice(1);
    const fileName = `${info.title.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 50)}.${ext}`;

    const successEmbed = new EmbedBuilder()
      .setColor(config.colors.success)
      .setTitle('✅ Download Complete!')
      .setDescription(`**${info.title}**`)
      .addFields(
        { name: '📦 Quality', value: quality.toUpperCase(), inline: true },
        { name: '💾 File Size', value: formatFileSize(fileSize), inline: true },
        { name: '🌐 Platform', value: platform, inline: true },
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}` })
      .setTimestamp();

    if (info.thumbnail) successEmbed.setThumbnail(info.thumbnail);

    try {
      await interaction.editReply({
        embeds: [successEmbed],
        files: [{ attachment: downloadedFile, name: fileName }],
      });
      logger.info(`[download] Sent file to ${interaction.user.tag} (${formatFileSize(fileSize)}) quality=${quality} platform=${platform}`);
    } catch (err) {
      logger.error(`[download] Failed to send file: ${err.message}`);
      await interaction.editReply({ embeds: [errorEmbed('Send Failed', 'Could not send the file. It may be too large or Discord is having issues.')] });
    } finally {
      setTimeout(() => deleteFile(downloadedFile), 5000);
    }
  },
};

function errorEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(0xED4245)
    .setTitle(`❌ ${title}`)
    .setDescription(description)
    .setTimestamp();
}
