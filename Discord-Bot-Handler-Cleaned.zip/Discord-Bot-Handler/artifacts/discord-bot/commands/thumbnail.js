const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const { getMediaInfo, downloadThumbnail } = require('../utils/ytdlp');
const { isValidUrl, detectPlatform } = require('../utils/validators');
const { checkCooldown } = require('../utils/queue');
const { deleteFile, tempDir } = require('../utils/cleanup');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('thumbnail')
    .setDescription('Extract the thumbnail image from a video URL')
    .addStringOption(opt =>
      opt.setName('url')
        .setDescription('The URL of the video')
        .setRequired(true)),

  async execute(interaction) {
    const url = interaction.options.getString('url');
    const userId = interaction.user.id;

    if (!isValidUrl(url)) {
      return interaction.reply({
        embeds: [errorEmbed('Invalid URL', 'Please provide a valid URL.')],
        ephemeral: true,
      });
    }

    const remaining = checkCooldown(userId);
    if (remaining > 0) {
      return interaction.reply({
        embeds: [errorEmbed('Cooldown Active', `Please wait **${remaining}s** before your next request.`)],
        ephemeral: true,
      });
    }

    await interaction.deferReply();
    const platform = detectPlatform(url);

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(config.colors.info)
          .setTitle('🖼️ Extracting Thumbnail...')
          .setDescription(`Fetching thumbnail from **${platform}**...`),
      ],
    });

    let info;
    try {
      info = await getMediaInfo(url);
    } catch (err) {
      logger.error(`[thumbnail] getMediaInfo failed: ${err.message}`);
      return interaction.editReply({ embeds: [errorEmbed('Failed to Fetch Info', err.message)] });
    }

    // Try to use direct thumbnail URL from info first
    if (info.thumbnail) {
      const embed = new EmbedBuilder()
        .setColor(config.colors.success)
        .setTitle('🖼️ Thumbnail Extracted')
        .setDescription(`**${info.title}**`)
        .addFields(
          { name: '👤 Uploader', value: info.uploader || 'Unknown', inline: true },
          { name: '🌐 Platform', value: platform, inline: true },
        )
        .setImage(info.thumbnail)
        .setFooter({ text: `Requested by ${interaction.user.tag}` })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
      logger.info(`[thumbnail] Sent thumbnail URL for ${interaction.user.tag}`);
      return;
    }

    // Fallback: download thumbnail file
    const tempFile = path.join(tempDir, `thumb_${Date.now()}_${userId}`);
    let thumbFile = null;

    try {
      thumbFile = await downloadThumbnail(url, tempFile);
    } catch (err) {
      logger.error(`[thumbnail] download failed: ${err.message}`);
      return interaction.editReply({ embeds: [errorEmbed('Thumbnail Not Found', 'Could not extract a thumbnail from this URL.')] });
    }

    if (!thumbFile || !fs.existsSync(thumbFile)) {
      return interaction.editReply({ embeds: [errorEmbed('Thumbnail Not Found', 'No thumbnail was found for this video.')] });
    }

    const ext = path.extname(thumbFile).slice(1) || 'png';
    const safeName = `thumbnail.${ext}`;

    const embed = new EmbedBuilder()
      .setColor(config.colors.success)
      .setTitle('🖼️ Thumbnail Extracted')
      .setDescription(`**${info.title}**`)
      .addFields(
        { name: '👤 Uploader', value: info.uploader || 'Unknown', inline: true },
        { name: '🌐 Platform', value: platform, inline: true },
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}` })
      .setTimestamp();

    try {
      await interaction.editReply({
        embeds: [embed],
        files: [{ attachment: thumbFile, name: safeName }],
      });
      logger.info(`[thumbnail] Sent thumbnail file to ${interaction.user.tag}`);
    } catch (err) {
      logger.error(`[thumbnail] send failed: ${err.message}`);
      await interaction.editReply({ embeds: [errorEmbed('Send Failed', 'Could not send the thumbnail.')] });
    } finally {
      setTimeout(() => deleteFile(thumbFile), 5000);
    }
  },
};

function errorEmbed(title, description) {
  return new EmbedBuilder().setColor(0xED4245).setTitle(`❌ ${title}`).setDescription(description).setTimestamp();
}
